package com.example.recyleview

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.labterminal.R
import com.example.services.munnazza
import kotlinx.android.synthetic.main.activity_servic.*

class Services : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.services)
        btnstart.setOnClickListener{
            Intent(this,munnazza::class.java).also {
                startService(it)
                txt1.text="Services is Running"
            }
        }
        btnstop.setOnClickListener{
            Intent(this,munnazza::class.java).also {
                stopService(it)
                txt1.text="Services is Stop"
            }
        }
        btnsend.setOnClickListener{
            Intent(this,munnazza::class.java).also{
                val data= edit.text.toString()
                it.putExtra("Extra data",data)
                startService(it)

            }
        }
    }
}