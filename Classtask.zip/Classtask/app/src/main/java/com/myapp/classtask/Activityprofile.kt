package com.myapp.classtask

class Activityprofile {

}